from machine import Pin, time_pulse_us
import time

# 1. Setup Traffic Light Pins
led_red = Pin(15, Pin.OUT)
led_yellow = Pin(14, Pin.OUT)
led_green = Pin(13, Pin.OUT)

# 2. Setup Ultrasonic Sensor Pins
trig = Pin(2, Pin.OUT)
echo = Pin(3, Pin.IN)

def get_distance():
    # Send a 10 microsecond pulse
    trig.value(0)
    time.sleep_us(2)
    trig.value(1)
    time.sleep_us(10)
    trig.value(0)
    
    # Measure the echo bounce time
    duration = time_pulse_us(echo, 1, 30000) # 30ms timeout
    if duration < 0:
        return -1
        
    # Convert time to centimeters
    return (duration * 0.0343) / 2

print("Hardware Node Online! Monitoring intersection...")

while True:
    dist = get_distance()
    
    if dist > 0:
        # Default State: Red Light
        if dist > 100:
            led_red.value(1)
            led_yellow.value(0)
            led_green.value(0)
            print(f"No cars close. Distance: {dist:.1f} cm | Signal: RED")
            
        # Car approaches! Change to Green.
        else:
            print(f"Car detected at {dist:.1f} cm! Changing signal...")
            # Quick yellow transition
            led_red.value(0)
            led_yellow.value(1)
            time.sleep(1)
            
            # Green light
            led_yellow.value(0)
            led_green.value(1)
            print("Signal: GREEN")
            time.sleep(3) # Hold green for a moment
            
    time.sleep(0.5)